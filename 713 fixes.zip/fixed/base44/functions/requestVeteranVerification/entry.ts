import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// FIX (new function): veteran_status used to be written directly from the
// browser via User.update — which meant any user could potentially set
// "verified_veteran" on themselves and get free access, since
// createStripeCheckout trusts that field.
//
// This function is now the ONLY intended path for a user to touch
// veteran_status, and the only transition it allows is:
//   regular -> pending_verification
// Actual verification (pending -> verified_veteran / disabled_vet /
// homeless_vet) stays an admin action in the Admin page.
//
// IMPORTANT: also restrict direct client writes to User.veteran_status in
// the Base44 dashboard if field-level write rules are available — this
// function closes the front door, that setting closes the back door.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const alreadyVerified = ['verified_veteran', 'disabled_vet', 'homeless_vet'];
    if (alreadyVerified.includes(user.veteran_status)) {
      return Response.json({ message: 'Already verified', veteran_status: user.veteran_status });
    }
    if (user.veteran_status === 'pending_verification') {
      return Response.json({ message: 'Verification already pending', veteran_status: 'pending_verification' });
    }

    // Service role write — the server decides the value, never the client.
    await base44.asServiceRole.entities.User.update(user.id, {
      veteran_status: 'pending_verification',
    });

    return Response.json({ success: true, veteran_status: 'pending_verification' });
  } catch (error) {
    console.error('requestVeteranVerification error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
