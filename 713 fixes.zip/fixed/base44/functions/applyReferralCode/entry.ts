import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// FIX (new function): referred_by_code used to be written directly from
// the browser via User.update. Moving it server-side lets us validate
// that the code actually belongs to another real user (no self-referral,
// no made-up codes inflating stats), and it removes one more reason for
// the client to have write access to its own User record.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { code } = await req.json().catch(() => ({}));
    if (!code || typeof code !== 'string') {
      return Response.json({ error: 'Missing referral code' }, { status: 400 });
    }

    if (user.referred_by_code) {
      return Response.json({ message: 'Referral code already applied' });
    }

    const db = base44.asServiceRole;
    const owners = await db.entities.User.filter({ referral_code: code });
    const owner = owners?.[0];

    if (!owner) {
      return Response.json({ error: 'Invalid referral code' }, { status: 400 });
    }
    if (owner.id === user.id) {
      return Response.json({ error: 'You cannot refer yourself' }, { status: 400 });
    }

    await db.entities.User.update(user.id, { referred_by_code: code });

    return Response.json({ success: true });
  } catch (error) {
    console.error('applyReferralCode error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
