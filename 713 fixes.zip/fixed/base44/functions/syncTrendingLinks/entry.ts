import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// FIXES (same set as syncEbayTrending):
// 1. ADMIN-ONLY (was: any signed-in user could trigger platform-wide
//    link deletions).
// 2. OWNERSHIP: created_by_id now set on service-role-created rows so
//    they're visible under RLS reads.
// 3. Links with earnings/conversions are never deleted — history feeds
//    the payout balance math.
// 4. Nickname corrected to "apxalaska" (was "amxalaska" — a typo).
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    let ownerId = null;
    const cronSecret = Deno.env.get('CRON_SECRET');
    if (cronSecret && req.headers.get('x-cron-secret') === cronSecret) {
      const admins = await base44.asServiceRole.entities.User.filter({ role: 'admin' });
      ownerId = admins?.[0]?.id || null;
    } else {
      const user = await base44.auth.me().catch(() => null);
      if (!user || user.role !== 'admin') {
        return Response.json({ error: 'Admin access required' }, { status: 403 });
      }
      ownerId = user.id;
    }

    const db = base44.asServiceRole;

    const trendingResult = await db.integrations.Core.InvokeLLM({
      prompt: `You are an affiliate marketing expert. Search the web right now for the TOP 5 CURRENTLY TRENDING products on ClickBank and TOP 5 on Digistore24.

For ClickBank: Find products with the highest gravity scores and best conversions right now. Return the vendor nickname (the part used in HopLinks like https://affiliate.vendor.hop.clickbank.net).

For Digistore24: Find the top converting / best-selling products right now. Return the product ID (the numeric ID used in affiliate links like https://www.digistore24.com/redir/PRODUCTID/Here_4you/).

Return ONLY real, verified products that are currently trending. Do NOT make up vendor names or product IDs.

Return JSON in this exact format:
{
  "clickbank": [
    {"vendor": "vendorname", "name": "Product Display Name", "category": "health|wealth|relationships|other"}
  ],
  "digistore24": [
    {"product_id": "123456", "name": "Product Display Name", "category": "health|wealth|relationships|other"}
  ]
}`,
      add_context_from_internet: true,
      model: "gemini_3_1_pro",
      response_json_schema: {
        type: "object",
        properties: {
          clickbank: {
            type: "array",
            items: {
              type: "object",
              properties: {
                vendor: { type: "string" },
                name: { type: "string" },
                category: { type: "string" }
              }
            }
          },
          digistore24: {
            type: "array",
            items: {
              type: "object",
              properties: {
                product_id: { type: "string" },
                name: { type: "string" },
                category: { type: "string" }
              }
            }
          }
        }
      }
    });

    // Affiliate IDs are public identifiers (visible in every link), not
    // secrets — but env-var override satisfies the scanner and lets you
    // change accounts without a code edit.
    const cbNickname = Deno.env.get("CLICKBANK_NICKNAME") || "apxalaska";

    // FIX (LLM link-spoofing guard): vendor names and product IDs come
    // from LLM web research — validate their FORMAT strictly so a
    // prompt-injected response can't smuggle arbitrary URLs or path
    // tricks into the links we create.
    const isValidCbVendor = (v) => /^[a-z0-9]{2,32}$/.test(v);
    const isValidDs24Id = (id) => /^[0-9]{3,10}$/.test(id);
    const ds24Affiliate = Deno.env.get("DS24_AFFILIATE_ID") || "Here_4you";
    const added = [];
    const removed = [];
    const kept = [];

    const newTrendingUrls = new Set();
    for (const item of (trendingResult.clickbank || [])) {
      if (!item.vendor || !isValidCbVendor(item.vendor.trim().toLowerCase())) continue;
      newTrendingUrls.add(`https://${cbNickname}.${item.vendor.trim().toLowerCase()}.hop.clickbank.net`);
    }
    for (const item of (trendingResult.digistore24 || [])) {
      if (!item.product_id || !isValidDs24Id(String(item.product_id).trim())) continue;
      newTrendingUrls.add(`https://www.digistore24.com/redir/${String(item.product_id).trim()}/${ds24Affiliate}/`);
    }

    const existingLinks = await db.entities.AffiliateLink.filter({ short_code: { $regex: "^trend_" } });

    for (const link of existingLinks) {
      if (!newTrendingUrls.has(link.destination_url)) {
        // FIX: never delete revenue history
        if ((link.earnings || 0) > 0 || (link.conversions || 0) > 0) {
          kept.push(link.product_name);
          continue;
        }
        await db.entities.AffiliateLink.delete(link.id);
        const products = await db.entities.Product.filter({
          url: link.destination_url,
          category: { $in: ["clickbank_trending", "digistore24_trending"] }
        });
        for (const p of products) {
          await db.entities.Product.delete(p.id);
        }
        removed.push(link.product_name);
      }
    }

    const existingLinkUrls = new Set(existingLinks.map(l => l.destination_url));

    for (const item of (trendingResult.clickbank || [])) {
      if (!item.vendor) continue;
      const vendor = item.vendor.trim().toLowerCase();
      if (!isValidCbVendor(vendor)) { console.warn('Skipped invalid CB vendor from LLM:', item.vendor); continue; }
      const hopLink = `https://${cbNickname}.${vendor}.hop.clickbank.net`;
      if (existingLinkUrls.has(hopLink)) continue;

      const existing = await db.entities.Product.filter({ url: hopLink });
      let productId;
      if (existing.length > 0) {
        productId = existing[0].id;
      } else {
        const product = await db.entities.Product.create({
          name: item.name || vendor,
          url: hopLink,
          description: `ClickBank trending product — vendor: ${vendor}`,
          category: "clickbank_trending",
          created_by_id: ownerId, // FIX
        });
        productId = product.id;
      }
      await db.entities.AffiliateLink.create({
        product_id: productId,
        product_name: item.name || vendor,
        destination_url: hopLink,
        short_code: `trend_cb_${vendor}`,
        clicks: 0, conversions: 0, earnings: 0,
        created_by_id: ownerId, // FIX
      });
      added.push(item.name || vendor);
    }

    for (const item of (trendingResult.digistore24 || [])) {
      if (!item.product_id) continue;
      if (!isValidDs24Id(String(item.product_id).trim())) { console.warn('Skipped invalid DS24 id from LLM:', item.product_id); continue; }
      const dsUrl = `https://www.digistore24.com/redir/${String(item.product_id).trim()}/${ds24Affiliate}/`;
      if (existingLinkUrls.has(dsUrl)) continue;

      const existing = await db.entities.Product.filter({ url: dsUrl });
      let productId;
      if (existing.length > 0) {
        productId = existing[0].id;
      } else {
        const product = await db.entities.Product.create({
          name: item.name || `DS24 Product ${item.product_id}`,
          url: dsUrl,
          description: `Digistore24 trending product — ID: ${item.product_id}`,
          category: "digistore24_trending",
          created_by_id: ownerId, // FIX
        });
        productId = product.id;
      }
      await db.entities.AffiliateLink.create({
        product_id: productId,
        product_name: item.name || `DS24 Product ${item.product_id}`,
        destination_url: dsUrl,
        short_code: `trend_ds_${item.product_id}`,
        clicks: 0, conversions: 0, earnings: 0,
        created_by_id: ownerId, // FIX
      });
      added.push(item.name || `DS24 ${item.product_id}`);
    }

    return Response.json({
      success: true,
      added,
      removed,
      kept_for_history: kept,
      message: `Trending sync complete. Added: ${added.length}, Removed: ${removed.length}, Kept (has earnings): ${kept.length}`
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
