import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    // FIX: pinned apiVersion (matches createStripeCheckout).
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"), { apiVersion: '2023-10-16' });
    const signature = req.headers.get('stripe-signature');

    // Verify webhook signature
    let event;
    try {
      const body = await req.text();
      event = await stripe.webhooks.constructEventAsync(
        body,
        signature,
        Deno.env.get("STRIPE_WEBHOOK_SECRET")
      );
    } catch (err) {
      console.error('Webhook signature verification failed:', err.message);
      return Response.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const db = base44.asServiceRole;

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;

        if (session.metadata?.base44_app_id !== Deno.env.get("BASE44_APP_ID")) {
          return Response.json({ message: 'Ignored - different app' });
        }

        await db.entities.Payment.create({
          user_id: session.metadata?.user_id,
          amount: session.amount_total / 100,
          currency: session.currency,
          status: 'completed',
          payment_method: 'stripe',
          transaction_id: session.id,
          plan_type: session.metadata?.plan_type,
          veteran_status: 'regular'
        });

        console.log('Payment recorded:', session.id);
        break;
      }

      // FIX (new): record subscription RENEWAL payments. Previously only
      // the initial checkout was recorded, so revenue history was missing
      // every renewal after month/year one.
      case 'invoice.payment_succeeded': {
        const invoice = event.data.object;

        // Skip the very first invoice — checkout.session.completed
        // already records that payment; this avoids double-counting.
        if (invoice.billing_reason === 'subscription_create') {
          break;
        }

        // Identify the user via the subscription's metadata (set by
        // createStripeCheckout's subscription_data).
        const subId = invoice.subscription;
        if (!subId) break;
        const sub = await stripe.subscriptions.retrieve(subId);
        const userId = sub.metadata?.user_id;
        if (!userId) {
          console.warn('Renewal invoice for subscription with no user_id metadata:', subId);
          break;
        }

        await db.entities.Payment.create({
          user_id: userId,
          amount: invoice.amount_paid / 100,
          currency: invoice.currency,
          status: 'completed',
          payment_method: 'stripe',
          transaction_id: invoice.id,
          plan_type: sub.metadata?.plan_type,
          veteran_status: 'regular'
        });

        console.log('Renewal payment recorded:', invoice.id);
        break;
      }

      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = event.data.object;
        const userId = subscription.metadata?.user_id;

        if (!userId) {
          console.warn('Subscription event with no user_id in metadata:', subscription.id);
          break;
        }

        const existing = await db.entities.Subscription.filter({ stripe_subscription_id: subscription.id });
        const subData = {
          user_id: userId,
          stripe_customer_id: subscription.customer,
          stripe_subscription_id: subscription.id,
          status: subscription.status,
          plan_type: subscription.metadata?.plan_type || existing?.[0]?.plan_type,
          current_period_end: subscription.current_period_end
            ? new Date(subscription.current_period_end * 1000).toISOString()
            : null,
          cancel_at_period_end: Boolean(subscription.cancel_at_period_end),
        };

        if (existing?.[0]) {
          await db.entities.Subscription.update(existing[0].id, subData);
        } else {
          await db.entities.Subscription.create(subData);
        }

        console.log('Subscription recorded:', subscription.id, subscription.status);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object;
        const existing = await db.entities.Subscription.filter({ stripe_subscription_id: subscription.id });
        if (existing?.[0]) {
          await db.entities.Subscription.update(existing[0].id, { status: 'canceled' });
        }
        console.log('Subscription canceled:', subscription.id);
        break;
      }

      case 'payment_intent.succeeded': {
        // Works now that createStripeCheckout sets payment_intent_data
        // metadata for lifetime purchases. Kept as a log-only checkpoint —
        // checkout.session.completed is the source of truth for recording.
        const paymentIntent = event.data.object;

        if (paymentIntent.metadata?.base44_app_id !== Deno.env.get("BASE44_APP_ID")) {
          return Response.json({ message: 'Ignored - different app' });
        }

        console.log('Payment succeeded:', paymentIntent.id);
        break;
      }

      default:
        console.log('Unhandled event type:', event.type);
    }

    return Response.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
