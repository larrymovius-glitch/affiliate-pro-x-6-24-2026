import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// FIX: removed the unauthenticated direct-token path. Previously anyone
// could hit this URL with ?ebaytkn=<junk> and it would DELETE the app's
// stored eBay token and replace it with attacker-supplied data — no
// signature, no session, no auth. The sessid exchange path that remains
// is self-verifying: FetchToken only succeeds at eBay's API for a session
// that eBay itself just created against OUR app credentials.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const url = new URL(req.url);

    const isAuth = url.searchParams.get("isAuth");
    const sessId = url.searchParams.get("sessid");
    const ruName = Deno.env.get("EBAY_RU_NAME") || "Lawerence_Moviu-Lawerenc-Affili-zgqyaq";

    if (isAuth === "false" || !sessId) {
      return Response.redirect("https://apx.amhere4utoday.com/", 302);
    }

    // Exchange the session ID for a user token via eBay's FetchToken API
    const fetchTokenXml = `<?xml version="1.0" encoding="utf-8"?>
<FetchTokenRequest xmlns="urn:ebay:apis:eBLBaseComponents">
  <RequesterCredentials>
    <eBayAuthToken></eBayAuthToken>
  </RequesterCredentials>
  <SessionID>${sessId}</SessionID>
</FetchTokenRequest>`;

    const ebayApiUrl = "https://api.ebay.com/ws/api.dll";
    const tokenRes = await fetch(ebayApiUrl, {
      method: "POST",
      headers: {
        "X-EBAY-API-COMPATIBILITY-LEVEL": "967",
        "X-EBAY-API-DEV-NAME": Deno.env.get("EBAY_DEV_ID") || "",
        "X-EBAY-API-APP-NAME": Deno.env.get("EBAY_APP_ID") || "",
        "X-EBAY-API-CERT-NAME": Deno.env.get("EBAY_CERT_ID") || "",
        "X-EBAY-API-CALL-NAME": "FetchToken",
        "X-EBAY-API-SITEID": "0",
        "Content-Type": "text/xml",
      },
      body: fetchTokenXml,
    });

    const tokenXml = await tokenRes.text();

    const tokenMatch = tokenXml.match(/<eBayAuthToken>([\s\S]*?)<\/eBayAuthToken>/);
    const expiresMatch = tokenXml.match(/<HardExpirationTime>([\s\S]*?)<\/HardExpirationTime>/);

    if (!tokenMatch) {
      console.error("eBay FetchToken failed:", tokenXml);
      return Response.redirect("https://apx.amhere4utoday.com/error", 302);
    }

    const ebayToken = tokenMatch[1].trim();
    const expiresAt = expiresMatch ? expiresMatch[1].trim() : null;

    // Only replace the stored token AFTER eBay has confirmed the exchange.
    await base44.asServiceRole.entities.EbayToken.deleteMany({});
    await base44.asServiceRole.entities.EbayToken.create({
      token: ebayToken,
      expires_at: expiresAt,
      ru_name: ruName,
      connected_at: new Date().toISOString(),
    });

    return Response.redirect("https://apx.amhere4utoday.com/", 302);

  } catch (error) {
    console.error("eBay OAuth callback error:", error.message);
    return Response.redirect("https://apx.amhere4utoday.com/", 302);
  }
});
