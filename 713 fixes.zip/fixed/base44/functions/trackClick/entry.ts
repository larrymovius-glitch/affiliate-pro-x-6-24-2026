import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Public redirect endpoint — finds the link, counts the click, redirects.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const db = base44.asServiceRole;

    const url = new URL(req.url);
    const code = url.searchParams.get('code');

    if (!code) {
      return Response.redirect(url.origin, 302);
    }

    const matches = await db.entities.AffiliateLink.filter({ short_code: code });
    const link = matches?.[0];

    if (!link || !link.destination_url) {
      return Response.redirect(url.origin, 302);
    }

    // FIX: was fire-and-forget. On serverless runtimes a pending promise
    // is not guaranteed to complete once the response returns, so click
    // counts were silently lost. It's one fast write — await it, but
    // never let a failed count block the visitor's redirect.
    try {
      await db.entities.AffiliateLink.update(link.id, { clicks: (link.clicks || 0) + 1 });
    } catch (err) {
      console.warn('Click count update failed (non-blocking):', err);
    }

    // Pass our short_code through as the network's click-id parameter so
    // their conversion postback can be matched back to this exact link.
    let destination = link.destination_url;
    try {
      const destUrl = new URL(destination);
      if (destUrl.hostname.endsWith('hop.clickbank.net')) {
        destUrl.searchParams.set('tid', link.short_code);
        destination = destUrl.toString();
      } else if (destUrl.hostname.includes('digistore24.com')) {
        destUrl.searchParams.set('cid', link.short_code);
        destination = destUrl.toString();
      }
    } catch (urlErr) {
      console.warn('Could not append tracking param to destination:', urlErr);
    }

    return Response.redirect(destination, 302);
  } catch (error) {
    console.error('trackClick error:', error);
    const fallbackOrigin = new URL(req.url).origin;
    return Response.redirect(fallbackOrigin, 302);
  }
});
