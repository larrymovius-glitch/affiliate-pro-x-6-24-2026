import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.0.0';

// FIXES:
// 1. Cancels any active Stripe subscription first — previously a deleted
//    account kept getting BILLED forever.
// 2. Also removes Subscription, Notification, and EbayToken rows
//    (service role — some of these aren't user-writable under RLS).
//    Payment rows are KEPT intentionally: they're financial records you
//    may need for taxes/refunds. Delete manually if user requests full
//    erasure and your jurisdiction allows it.
// 3. Deletes the User record itself (was left behind before) — this also
//    makes the eBay account-deletion compliance endpoint's claim true.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const db = base44.asServiceRole;

    // 1. Cancel Stripe subscription(s) so billing stops immediately.
    try {
      const subs = await db.entities.Subscription.filter({ user_id: user.id });
      const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
      if (stripeKey && subs?.length) {
        const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' });
        for (const sub of subs) {
          if (sub.stripe_subscription_id && ['active', 'trialing', 'past_due'].includes(sub.status)) {
            await stripe.subscriptions.cancel(sub.stripe_subscription_id).catch((e) =>
              console.warn(`Could not cancel Stripe sub ${sub.stripe_subscription_id}:`, e.message)
            );
          }
          await db.entities.Subscription.delete(sub.id);
        }
      } else {
        for (const sub of (subs || [])) {
          await db.entities.Subscription.delete(sub.id);
        }
      }
    } catch (subErr) {
      console.warn('Subscription cleanup failed (continuing):', subErr);
    }

    // 2. Delete all user-owned content
    const [links, products, campaigns, payouts, posts, adReviews, adAssets, schedules, notifications] = await Promise.all([
      db.entities.AffiliateLink.filter({ created_by_id: user.id }),
      db.entities.Product.filter({ created_by_id: user.id }),
      db.entities.Campaign.filter({ created_by_id: user.id }),
      db.entities.Payout.filter({ created_by_id: user.id }),
      db.entities.GeneratedPost.filter({ created_by_id: user.id }),
      db.entities.AdReview.filter({ created_by_id: user.id }),
      db.entities.AdAsset.filter({ created_by_id: user.id }),
      db.entities.PayoutSchedule.filter({ created_by_id: user.id }),
      db.entities.Notification.filter({ user_id: user.id }),
    ]);

    await Promise.all([
      ...links.map(r => db.entities.AffiliateLink.delete(r.id)),
      ...products.map(r => db.entities.Product.delete(r.id)),
      ...campaigns.map(r => db.entities.Campaign.delete(r.id)),
      ...payouts.map(r => db.entities.Payout.delete(r.id)),
      ...posts.map(r => db.entities.GeneratedPost.delete(r.id)),
      ...adReviews.map(r => db.entities.AdReview.delete(r.id)),
      ...adAssets.map(r => db.entities.AdAsset.delete(r.id)),
      ...schedules.map(r => db.entities.PayoutSchedule.delete(r.id)),
      ...notifications.map(r => db.entities.Notification.delete(r.id)),
    ]);

    // 3. Finally, delete the User record itself.
    try {
      await db.entities.User.delete(user.id);
    } catch (userErr) {
      // Some platforms manage User rows via auth, not entities — log and
      // report so this doesn't silently half-delete.
      console.error('Could not delete User record:', userErr);
      return Response.json({
        success: true,
        warning: 'Content deleted, but the account record itself could not be removed automatically. Remove it from the admin panel.'
      });
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
