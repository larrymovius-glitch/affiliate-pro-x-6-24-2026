import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const db = base44.asServiceRole;
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"), { apiVersion: '2023-10-16' });
    const { payoutId, veteranEmail, amount } = await req.json();

    if (!payoutId || !veteranEmail || !amount || amount <= 0) {
      return Response.json({ error: 'Invalid payout data' }, { status: 400 });
    }

    // FIX: look up the recipient and use their saved Stripe CONNECTED
    // ACCOUNT id as the transfer destination. Previously this passed the
    // recipient's *email* to stripe.transfers.create, which Stripe always
    // rejects — every payout attempt failed.
    const matchingUsers = await db.entities.User.filter({ email: veteranEmail });
    const recipient = matchingUsers?.[0];

    if (!recipient) {
      return Response.json({ error: `No user found for ${veteranEmail}` }, { status: 404 });
    }
    if (!recipient.stripeAccountId || !recipient.stripeAccountId.startsWith('acct_')) {
      return Response.json({
        error: 'Recipient has not completed payment setup (missing Stripe connected account). Ask them to add it in Payouts → Payment Info.'
      }, { status: 400 });
    }

    // FIX: balance check is now scoped to the RECIPIENT's own earnings
    // and payouts. Previously it summed every user's earnings platform-
    // wide, so one user could be paid out of another user's balance.
    const userLinks = await db.entities.AffiliateLink.filter({ created_by_id: recipient.id });
    const totalEarned = userLinks.reduce((sum, l) => sum + (l.earnings || 0), 0);

    const userPayouts = await db.entities.Payout.filter({ created_by_id: recipient.id });
    const totalPaid = userPayouts
      .filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + (p.amount || 0), 0);

    const availableBalance = totalEarned - totalPaid;

    if (amount > availableBalance) {
      return Response.json({
        error: 'Insufficient balance',
        available: availableBalance,
        requested: amount
      }, { status: 400 });
    }

    // Create Stripe transfer (requires Stripe Connect; the platform
    // account must carry sufficient balance for transfers).
    const transfer = await stripe.transfers.create({
      amount: Math.round(amount * 100),
      currency: 'usd',
      destination: recipient.stripeAccountId,
      transfer_group: `payout_${payoutId}`,
    });

    await db.entities.Payout.update(payoutId, {
      status: 'paid',
      paid_at: new Date().toISOString(),
      payment_method: 'stripe',
      transaction_id: transfer.id
    });

    // Best-effort completion notification.
    try {
      await db.entities.Notification.create({
        user_id: recipient.id,
        type: 'payout_completed',
        title: 'Your payout is on its way',
        body: `$${amount.toFixed(2)} has been sent to you.`,
        link_to: '/payouts',
      });
    } catch (notifyError) {
      console.warn('Payout succeeded but notification failed:', notifyError);
    }

    return Response.json({
      success: true,
      transfer_id: transfer.id,
      amount: amount
    });
  } catch (error) {
    console.error('Payout error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
