import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// FIX: appends the affiliate link to the post text — previously the
// affiliateLink parameter was accepted and silently ignored, so LinkedIn
// posts went out with no link, defeating the purpose. (Token was already
// in Authorization headers here — no URL-token issue in this one.)
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { accessToken } = await base44.asServiceRole.connectors.getCurrentAppUserConnection("6a3a1c4e98737984ce1e0230");

    const { postContent, affiliateLink } = await req.json();

    if (!postContent) {
      return Response.json({ error: 'Post content is required' }, { status: 400 });
    }

    // Include the affiliate link in the share text if provided
    const fullText = affiliateLink ? `${postContent}\n\n${affiliateLink}` : postContent;

    const profileRes = await fetch('https://api.linkedin.com/v2/me?projection=(id,firstName,lastName)', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'X-Restli-Protocol-Version': '2.0.0'
      }
    });

    if (!profileRes.ok) {
      const errorData = await profileRes.json();
      return Response.json({ error: 'Failed to get LinkedIn profile', details: errorData }, { status: 400 });
    }

    const profile = await profileRes.json();
    const personUrn = `urn:li:person:${profile.id}`;

    const postPayload = {
      author: personUrn,
      lifecycleState: 'PUBLISHED',
      specificContent: {
        'com.linkedin.ugc.ShareContent': {
          shareCommentary: {
            text: fullText
          },
          shareMediaCategory: 'NONE'
        }
      },
      visibility: {
        'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC'
      }
    };

    const postRes = await fetch('https://api.linkedin.com/v2/ugcPosts', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'X-Restli-Protocol-Version': '2.0.0'
      },
      body: JSON.stringify(postPayload)
    });

    if (!postRes.ok) {
      const errorData = await postRes.json();
      return Response.json({ error: 'Failed to create LinkedIn post', details: errorData }, { status: 400 });
    }

    const postData = await postRes.json();

    const savedPost = await base44.entities.GeneratedPost.create({
      content: fullText,
      platform: "linkedin",
      status: "posted",
      product_name: "LinkedIn Auto Post",
      ai_score: 10
    });

    return Response.json({
      success: true,
      postId: postData.id,
      linkedInPostId: savedPost.id,
      message: 'Posted to LinkedIn successfully!'
    });

  } catch (error) {
    console.error('LinkedIn post error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
