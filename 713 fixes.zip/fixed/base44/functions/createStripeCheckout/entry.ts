import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import Stripe from 'npm:stripe@14.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // FIX: pin apiVersion so webhook payload shapes don't shift when
    // Stripe rolls the account default forward.
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"), { apiVersion: '2023-10-16' });
    const { planType } = await req.json();

    const validPlans = ['monthly', 'yearly', 'lifetime'];
    if (!validPlans.includes(planType)) {
      return Response.json({ error: 'Invalid plan type' }, { status: 400 });
    }

    const priceIds = {
      monthly: 'price_1TlONtLiK3PoXkX5WStUc9On',
      yearly: 'price_1TlONuLiK3PoXkX5lI4jLfip',
      lifetime: null // Lifetime is one-time, handled with inline price_data below
    };

    // Veterans get free access — checked against this user's own real,
    // database-backed status, never trusted from client input.
    const verifiedVeteranStatuses = ['verified_veteran', 'disabled_vet', 'homeless_vet'];
    if (verifiedVeteranStatuses.includes(user.veteran_status)) {
      return Response.json({
        message: 'Veteran discount applied - free access granted',
        veteranAccess: true
      });
    }

    const sharedMetadata = {
      base44_app_id: Deno.env.get("BASE44_APP_ID"),
      user_id: user.id,
      user_email: user.email,
      plan_type: planType
    };

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: planType === 'lifetime' ? [{
        price_data: {
          currency: 'usd',
          product_data: { name: 'Affiliate Pro X - Lifetime Access' },
          unit_amount: 99700
        },
        quantity: 1
      }] : [{
        price: priceIds[planType],
        quantity: 1,
      }],
      mode: planType === 'lifetime' ? 'payment' : 'subscription',
      success_url: `${Deno.env.get("BASE44_APP_URL")}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${Deno.env.get("BASE44_APP_URL")}/pricing?canceled=true`,
      metadata: sharedMetadata,
      // Session metadata does NOT carry over to the Subscription object —
      // without this the subscription webhook can't tell whose it is.
      subscription_data: planType === 'lifetime' ? undefined : {
        metadata: {
          user_id: user.id,
          plan_type: planType
        }
      },
      // FIX: same problem for one-time payments — session metadata does
      // NOT carry over to the PaymentIntent either, so the webhook's
      // payment_intent.succeeded handler always saw empty metadata and
      // ignored every lifetime purchase as "different app".
      payment_intent_data: planType === 'lifetime' ? {
        metadata: sharedMetadata
      } : undefined,
      customer_email: user.email,
    });

    return Response.json({ url: session.url, sessionId: session.id });
  } catch (error) {
    console.error('Stripe checkout error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
