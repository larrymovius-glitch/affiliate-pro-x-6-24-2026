import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Receives real conversion (sale) confirmations from affiliate networks.
// No user auth: this is called by ClickBank's or Digistore24's servers.
//
// FIX: added a shared-secret check. Previously anyone who knew or guessed
// a short_code could fake conversions, inflate earnings (which feed the
// payout balance math!), and trigger bogus "You made a sale!" alerts.
//
// SETUP:
// 1. Add a secret in Base44: CONVERSION_SECRET (any long random string).
// 2. Include it in the postback URLs you configure at each network:
//
// ClickBank:  Account Settings → My Site → Postback/Pixels → Add Integration
//   https://<your-app-domain>/functions/trackConversion?secret=<CONVERSION_SECRET>&code={tid}&amount={commission}&network=clickbank
//
// Digistore24:  Sales & partners → Integrations → S2S Postback
//   https://<your-app-domain>/functions/trackConversion?secret=<CONVERSION_SECRET>&code={cid}&amount={amount_affiliate}&network=digistore24
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const db = base44.asServiceRole;

    const url = new URL(req.url);

    // Shared-secret gate. Returns 200 (not 401/403) so a probing attacker
    // learns nothing and the networks never see an "error" that could make
    // them disable the integration during setup mistakes.
    const expectedSecret = Deno.env.get('CONVERSION_SECRET');
    const providedSecret = url.searchParams.get('secret');
    if (!expectedSecret || providedSecret !== expectedSecret) {
      console.warn('trackConversion: missing or wrong secret — ignoring postback');
      return new Response('OK', { status: 200 });
    }

    const code = url.searchParams.get('code');
    const amountRaw = url.searchParams.get('amount');
    const network = url.searchParams.get('network') || 'unknown';
    const amount = parseFloat(amountRaw);

    if (!code || isNaN(amount)) {
      console.warn(`trackConversion: missing/invalid code or amount (network=${network}, code=${code}, amount=${amountRaw})`);
      return new Response('OK', { status: 200 });
    }

    const matches = await db.entities.AffiliateLink.filter({ short_code: code });
    const link = matches?.[0];

    if (!link) {
      console.warn(`trackConversion: no link found for code=${code} (network=${network})`);
      return new Response('OK', { status: 200 });
    }

    await db.entities.AffiliateLink.update(link.id, {
      conversions: (link.conversions || 0) + 1,
      earnings: (link.earnings || 0) + amount,
    });

    // Best-effort: let the link's owner know they made a sale.
    try {
      if (link.created_by_id) {
        await db.entities.Notification.create({
          user_id: link.created_by_id,
          type: 'milestone',
          title: 'You made a sale!',
          body: `${link.product_name || 'A product'} just earned $${amount.toFixed(2)}.`,
          link_to: '/dashboard',
        });
      }
    } catch (notifyErr) {
      console.warn('Conversion notification failed (non-blocking):', notifyErr);
    }

    return new Response('OK', { status: 200 });
  } catch (error) {
    console.error('trackConversion error:', error);
    // Still 200 — a network retrying a failed postback forever is worse
    // than losing one and seeing the error in logs.
    return new Response('OK', { status: 200 });
  }
});
