import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// FIX: two problems removed.
// 1. AUTH BYPASS: any unauthenticated request used to fall into the
//    "scheduler" branch and run with service role. Scheduled runs must
//    now present a CRON_SECRET header; everything else requires admin.
//    SETUP: add a secret CRON_SECRET in Base44 and configure the
//    scheduler to send header  X-Cron-Secret: <value>.
// 2. DEAD LLM CALL: every run made a paid InvokeLLM call whose result
//    was thrown away ("return an empty array"). Removed.
//
// NOTE: this function still only advances schedule timestamps — actual
// payout execution lives in processStripePayout. Wire real pending-payout
// fetching in here when the affiliate API integration is ready.
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    let authorized = false;
    const cronSecret = Deno.env.get('CRON_SECRET');
    if (cronSecret && req.headers.get('x-cron-secret') === cronSecret) {
      authorized = true; // scheduled run
    } else {
      try {
        const user = await base44.auth.me();
        authorized = user?.role === 'admin';
      } catch {
        authorized = false;
      }
    }

    if (!authorized) {
      return Response.json({ error: 'Forbidden: Admin access or valid cron secret required' }, { status: 403 });
    }

    const db = base44.asServiceRole;

    const schedules = await db.entities.PayoutSchedule.filter({ is_active: true });

    if (!schedules || schedules.length === 0) {
      return Response.json({ message: 'No active payout schedules found', processed: 0 });
    }

    const results = [];

    for (const schedule of schedules) {
      const now = new Date();

      const lastProcessed = schedule.last_processed_at ? new Date(schedule.last_processed_at) : null;
      let shouldProcess = false;

      if (!lastProcessed) {
        shouldProcess = true;
      } else {
        const diffDays = (now - lastProcessed) / (1000 * 60 * 60 * 24);
        const thresholds = { daily: 1, weekly: 7, biweekly: 14, monthly: 30 };
        shouldProcess = diffDays >= (thresholds[schedule.frequency] || 7);
      }

      if (!shouldProcess) {
        results.push({ schedule_id: schedule.id, skipped: true, reason: 'Not yet due' });
        continue;
      }

      const nextDates = { daily: 1, weekly: 7, biweekly: 14, monthly: 30 };
      const nextDate = new Date(now);
      nextDate.setDate(nextDate.getDate() + (nextDates[schedule.frequency] || 7));

      await db.entities.PayoutSchedule.update(schedule.id, {
        last_processed_at: now.toISOString(),
        next_payout_date: nextDate.toISOString().split('T')[0],
      });

      results.push({
        schedule_id: schedule.id,
        processed: true,
        frequency: schedule.frequency,
        minimum_amount: schedule.minimum_amount,
        payment_method: schedule.payment_method,
        payment_email: schedule.payment_email,
        next_payout_date: nextDate.toISOString().split('T')[0],
        timestamp: now.toISOString(),
      });
    }

    return Response.json({
      message: 'Auto-payout run complete',
      processed: results.filter(r => r.processed).length,
      skipped: results.filter(r => r.skipped).length,
      results,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});
