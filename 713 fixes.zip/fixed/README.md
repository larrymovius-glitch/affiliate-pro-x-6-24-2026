# Affiliate Pro X — Fixes Applied

All corrected files are in this `fixed/` folder, mirroring the repo layout.
Copy each over its original in Base44, then do the SETUP steps below.

## Fixed files

**Entities**
- `entities/Notification.jsonc` — client create locked to admin (was open: anyone could push phishing notifications into any user's inbox).
- `entities/EbayToken.jsonc` — added full admin-only RLS (had none: users could potentially read the app's eBay auth token).
- `entities/Payout.jsonc` — client create locked to admin (was open: users could insert arbitrary payout rows).
- `entities/Subscription.jsonc` — RLS create locked to admin (was open: any user could forge an active subscription and get paid features free).
- `entities/Payment.jsonc` — added a full RLS block (had none): users read own payments, writes admin/webhook only.

**Backend functions**
- `functions/requestVeteranVerification/entry.ts` — NEW. Only legal path for a user to request veteran status (regular → pending only).
- `functions/applyReferralCode/entry.ts` — NEW. Validates referral codes server-side (real code, no self-referral).
- `functions/trackConversion/entry.ts` — postbacks now require a shared secret (?secret=...). Setup below.
- `functions/trackClick/entry.ts` — click-count write is awaited (was fire-and-forget → lost clicks).
- `functions/createStripeCheckout/entry.ts` — lifetime purchases now carry metadata to the PaymentIntent; apiVersion pinned.
- `functions/stripeWebhook/entry.ts` — records subscription RENEWAL payments (invoice.payment_succeeded); apiVersion pinned.
- `functions/processStripePayout/entry.ts` — transfers to the recipient's Stripe connected account (was: their email — always failed); balance check scoped to the recipient (was platform-wide).
- `functions/processAutoPayouts/entry.ts` — auth bypass closed (unauthenticated calls used to run with service role); pointless paid LLM call removed.
- `functions/ebayOAuthCallback/entry.ts` — unauthenticated token-overwrite path removed (anyone could wipe/replace your eBay token).
- `functions/generatePremiumSpeech/entry.ts` — chunked base64 encoding (was a guaranteed stack-overflow crash on normal-length audio).
- `functions/syncEbayTrending/entry.ts` + `functions/syncTrendingLinks/entry.ts` — admin/cron-only (any user could trigger platform-wide deletions); created links/products now get an owner so they're visible under RLS; links with earnings are never deleted (history feeds payouts).
- `functions/dailyPerformanceSummary/entry.ts` — works both per-user and on a cron schedule (was 401-ing forever if scheduled).
- `functions/generateEbayPosts/entry.ts` — link_id now references the AffiliateLink (was the Product id).
- `functions/deleteAccount/entry.ts` — cancels the Stripe subscription (deleted accounts kept getting billed!), removes Subscription/Notification rows, deletes the User record. Payment rows kept as financial records.
- `functions/postToInstagram/entry.ts` — access token moved out of URLs; invalid posted_at field removed.
- `functions/postToLinkedIn/entry.ts` — affiliate link is now actually included in the post (was silently dropped).

**Frontend**
- `src/pages/Pricing.jsx` — veteran request goes through the new backend function; iframe check moved BEFORE session creation.
- `src/lib/AuthContext.jsx` — referral code applied via the new backend function.

## Security-scanner items addressed (second pass)
- Hardcoded ClickBank nickname / Digistore24 ID / eBay RuName → now read from env vars (`CLICKBANK_NICKNAME`, `DS24_AFFILIATE_ID`, `EBAY_RU_NAME`) with the confirmed values as fallbacks. These are public identifiers, not secrets — the fallbacks are safe and keep everything working if the vars aren't set.
- CRON_SECRET has NO hardcoded fallback anywhere in these files — if the env var is missing, scheduled auth fails closed. If the scanner flags a fallback, that's in code Base44 generated on its side, not in these files.
- LLM link-spoofing guard: syncTrendingLinks now validates vendor names (^[a-z0-9]{2,32}$) and Digistore24 IDs (numeric) before building URLs; syncEbayTrending sanitizes LLM search terms. A prompt-injected LLM response can no longer smuggle arbitrary URLs into created links.
- Still to do in Base44's dashboard (not code): X-Frame-Options header (Settings → Security), and check WHICH two functions the scanner says "anyone can run" — trackClick/trackConversion must stay public (by design), everything else should require auth.
- Entities the scanner flagged for public access that I don't have schemas for (ClickEvent, Conversion — these may exist only in the live app): apply the same pattern — read scoped to owner, writes admin/service-role only.

## SETUP required (secrets to add in Base44 → Settings → Secrets)

1. `CONVERSION_SECRET` — any long random string. Then update your postback URLs at ClickBank/Digistore24 to include `&secret=<value>` (exact URL formats are in trackConversion/entry.ts comments).
2. `CRON_SECRET` — any long random string. Configure your scheduler to send header `X-Cron-Secret: <value>` when calling processAutoPayouts, dailyPerformanceSummary, or the sync functions.

## Things I could NOT fix from here — do these manually

1. **Lock client writes to the User entity** (most important). Users can currently update their own User record from the browser — including, potentially, `veteran_status: "verified_veteran"` (= free paid access) and `stripeAccountId` (= redirect someone's payout). In Base44, restrict which User fields are client-writable; the new backend functions replace the legitimate uses.
2. ~~ClickBank nickname~~ — RESOLVED: confirmed as `apxalaska`; both sync functions updated. Nothing left to do here (importClickBank is dead code anyway — delete it, see below).
3. **Verify Stripe price IDs** in createStripeCheckout match your live Stripe products.
4. **Stripe Connect**: payouts via processStripePayout require recipients to have completed Stripe connected-account onboarding (`acct_...` saved via savePaymentInfo). An email alone can't receive a transfer.
5. **`src/lib/api.js`** routes through a custom `affiliate-pro-api` integration while the app also uses Base44 entities directly — two sources of truth. If that external API isn't live, delete api.js and its usages.
6. **importClickBank** function is self-described dead debug code — delete it.
7. Verify `created_by_id` is the correct creator field name in Base44 (vs `created_by` email) — several fixes depend on it, matching what your existing code already used.
