import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Link2, Copy, Trash2, ExternalLink, Search, MousePointerClick, RefreshCw, ShoppingBag } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { format } from "date-fns";
import { usePullToRefresh } from "@/hooks/usePullToRefresh";
import AffiliateDisclosure from "@/components/AffiliateDisclosure";
import EasyClickBank from "@/components/products/EasyClickBank";

function sanitizeShortCode(value) {
  return String(value || "link")
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .substring(0, 18) || "link";
}

function makeUniqueShortCode(base, links = []) {
  const existing = new Set(links.map(l => l.short_code));
  const cleanBase = sanitizeShortCode(base);
  let code = cleanBase;
  let i = 2;
  while (existing.has(code)) {
    code = `${cleanBase}_${i}`.substring(0, 24);
    i += 1;
  }
  return code;
}

function generateShortCode(links = []) {
  const existing = new Set(links.map(l => l.short_code));
  let code = Math.random().toString(36).substring(2, 8).toUpperCase();
  while (existing.has(code)) {
    code = Math.random().toString(36).substring(2, 8).toUpperCase();
  }
  return code;
}

function buildTrackingUrl(link) {
  return `${window.location.origin}/functions/trackClick?code=${encodeURIComponent(link.short_code)}`;
}

export default function Links() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [cbDialogOpen, setCbDialogOpen] = useState(false);
  const [cbVendor, setCbVendor] = useState("");
  const [cbNickname] = useState("amxalaska");
  const [dsDialogOpen, setDsDialogOpen] = useState(false);
  const [dsProductId, setDsProductId] = useState("");
  const [dsProductName, setDsProductName] = useState("");
  const [jvProductName, setJvProductName] = useState("");
  const [jvProductUrl, setJvProductUrl] = useState("");
  const [search, setSearch] = useState("");
  const [selectedProductId, setSelectedProductId] = useState("");
  const queryClient = useQueryClient();

  const { data: links = [], isLoading, refetch } = useQuery({
    queryKey: ["links"],
    queryFn: () => base44.entities.AffiliateLink.list("-created_date", 100),
  });

  const { onTouchStart, onTouchMove, onTouchEnd, pullDistance, pulling } = usePullToRefresh(() => refetch());

  const { data: products = [] } = useQuery({
    queryKey: ["products"],
    queryFn: () => base44.entities.Product.list("-created_date", 100),
  });

  const createMutation = useMutation({
    mutationFn: async (productId) => {
      const product = products.find(p => p.id === productId);
      if (!product) throw new Error("Product not found");
      return base44.entities.AffiliateLink.create({
        product_id: product.id,
        product_name: product.name,
        destination_url: product.url,
        short_code: generateShortCode(links),
        clicks: 0,
        conversions: 0,
        earnings: 0,
      });
    },
    onMutate: async (productId) => {
      await queryClient.cancelQueries({ queryKey: ["links"] });
      const previous = queryClient.getQueryData(["links"]);
      const product = products.find(p => p.id === productId);
      const optimistic = {
        id: `optimistic-${Date.now()}`,
        product_id: productId,
        product_name: product?.name || "...",
        destination_url: product?.url || "",
        short_code: "------",
        clicks: 0, conversions: 0, earnings: 0,
        created_date: new Date().toISOString(),
        _optimistic: true,
      };
      queryClient.setQueryData(["links"], old => [optimistic, ...(old || [])]);
      return { previous };
    },
    onError: (_err, _vars, context) => {
      queryClient.setQueryData(["links"], context.previous);
      toast.error("Failed to create link");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["links"] });
      setDialogOpen(false);
      setSelectedProductId("");
      toast.success("Link created!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AffiliateLink.delete(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ["links"] });
      const previous = queryClient.getQueryData(["links"]);
      queryClient.setQueryData(["links"], old => (old || []).filter(l => l.id !== id));
      return { previous };
    },
    onError: (_err, _vars, context) => {
      queryClient.setQueryData(["links"], context.previous);
      toast.error("Failed to delete link");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["links"] });
      toast.success("Link deleted");
    },
  });

  const cbHopLink = cbVendor ? `https://${cbNickname}.${cbVendor.trim().toLowerCase()}.hop.clickbank.net` : "";

  const addClickBankMutation = useMutation({
    mutationFn: async () => {
      const vendor = cbVendor.trim().toLowerCase();
      const hopLink = `https://${cbNickname}.${vendor}.hop.clickbank.net`;
      // Create product if not exists
      const existing = await base44.entities.Product.filter({ name: vendor });
      let productId;
      if (existing.length > 0) {
        productId = existing[0].id;
      } else {
        const product = await base44.entities.Product.create({
          name: vendor,
          url: hopLink,
          description: `ClickBank product — vendor: ${vendor}`,
          category: "clickbank",
        });
        productId = product.id;
      }
      return base44.entities.AffiliateLink.create({
        product_id: productId,
        product_name: vendor,
        destination_url: hopLink,
        short_code: makeUniqueShortCode(`cb_${vendor}`, links),
        clicks: 0, conversions: 0, earnings: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["links"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      setCbDialogOpen(false);
      setCbVendor("");
      toast.success("ClickBank HopLink added!");
    },
    onError: () => toast.error("Failed to add HopLink"),
  });

  const addDigistoreMutation = useMutation({
    mutationFn: async () => {
      const productId = dsProductId.trim();
      const name = dsProductName.trim() || `DS24 Product ${productId}`;
      const url = `https://www.digistore24.com/redir/${productId}/Here_4you/`;
      const existing = await base44.entities.Product.filter({ url });
      let productEntityId;
      if (existing.length > 0) {
        productEntityId = existing[0].id;
      } else {
        const product = await base44.entities.Product.create({
          name,
          url,
          description: `Digistore24 product — ID: ${productId}`,
          category: "digistore24",
        });
        productEntityId = product.id;
      }
      return base44.entities.AffiliateLink.create({
        product_id: productEntityId,
        product_name: name,
        destination_url: url,
        short_code: makeUniqueShortCode(`ds_${productId}`, links),
        clicks: 0, conversions: 0, earnings: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["links"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      setDsDialogOpen(false);
      setDsProductId("");
      setDsProductName("");
      toast.success("Digistore24 link added!");
    },
    onError: () => toast.error("Failed to add Digistore24 link"),
  });

  const addAnyLinkMutation = useMutation({
    mutationFn: async () => {
      const name = jvProductName.trim();
      const url = jvProductUrl.trim();
      const existing = await base44.entities.Product.filter({ name });
      let productEntityId;
      if (existing.length > 0) {
        productEntityId = existing[0].id;
      } else {
        const product = await base44.entities.Product.create({
          name,
          url,
          description: `Affiliate product`,
          category: "general",
        });
        productEntityId = product.id;
      }
      return base44.entities.AffiliateLink.create({
        product_id: productEntityId,
        product_name: name,
        destination_url: url,
        short_code: makeUniqueShortCode(`link_${name}`, links),
        clicks: 0, conversions: 0, earnings: 0,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["links"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      setDialogOpen(false);
      setJvProductUrl("");
      setJvProductName("");
      toast.success("Link added!");
    },
    onError: () => toast.error("Failed to add link"),
  });

  const copyLink = (link) => {
    navigator.clipboard.writeText(buildTrackingUrl(link));
    toast.success("Tracking link copied to clipboard!");
  };

  const filtered = links.filter(l =>
    !search || l.short_code?.toLowerCase().includes(search.toLowerCase()) ||
    l.product_name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6" onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
      {/* Pull-to-refresh indicator */}
      <div className="ptr-indicator" style={{ height: pullDistance }}>
        <RefreshCw className={`w-5 h-5 text-violet-400 transition-transform ${pulling ? "animate-spin" : ""}`} style={{ transform: `rotate(${pullDistance * 2}deg)` }} />
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold tracking-tight">Links</h1>
          <p className="text-muted-foreground text-sm mt-1">Create and manage your affiliate tracking links</p>
        </div>

      <EasyClickBank />
      </div>

      <AffiliateDisclosure />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex gap-2 flex-wrap">
        {/* ClickBank HopLink Dialog */}
        <Dialog open={cbDialogOpen} onOpenChange={setCbDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="gap-2 h-11" style={{ userSelect: "none" }}>
              <ShoppingBag className="w-4 h-4 text-orange-400" /> ClickBank
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display">Add ClickBank HopLink</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Enter the <strong>vendor nickname</strong> found in the ClickBank Marketplace product URL.</p>
              <div className="space-y-2">
                <Label>Vendor Nickname</Label>
                <Input
                  placeholder="e.g. vendorname"
                  value={cbVendor}
                  onChange={e => setCbVendor(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && cbVendor.trim() && addClickBankMutation.mutate()}
                />
              </div>
              {cbVendor.trim() && (
                <div className="p-3 rounded-lg bg-muted text-xs">
                  <p className="text-muted-foreground">Your HopLink will be:</p>
                  <p className="font-mono text-foreground break-all mt-1">{cbHopLink}</p>
                </div>
              )}
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setCbDialogOpen(false)}>Cancel</Button>
                <Button onClick={() => addClickBankMutation.mutate()} disabled={addClickBankMutation.isPending || !cbVendor.trim()}>
                  {addClickBankMutation.isPending ? "Adding..." : "Add HopLink"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Digistore24 Dialog */}
        <Dialog open={dsDialogOpen} onOpenChange={setDsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="gap-2 h-11" style={{ userSelect: "none" }}>
              <ShoppingBag className="w-4 h-4 text-blue-400" /> Digistore24
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display">Add Digistore24 Link</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Enter the <strong>product ID</strong> from the Digistore24 product page URL.</p>
              <div className="space-y-2">
                <Label>Product Name</Label>
                <Input
                  placeholder="e.g. Weight Loss Program"
                  value={dsProductName}
                  onChange={e => setDsProductName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Product ID</Label>
                <Input
                  placeholder="e.g. 123456"
                  value={dsProductId}
                  onChange={e => setDsProductId(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && dsProductId.trim() && addDigistoreMutation.mutate()}
                />
              </div>
              {dsProductId.trim() && (
                <div className="p-3 rounded-lg bg-muted text-xs">
                  <p className="text-muted-foreground">Your affiliate link will be:</p>
                  <p className="font-mono text-foreground break-all mt-1">https://www.digistore24.com/redir/{dsProductId}/Here_4you/</p>
                </div>
              )}
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => setDsDialogOpen(false)}>Cancel</Button>
                <Button onClick={() => addDigistoreMutation.mutate()} disabled={addDigistoreMutation.isPending || !dsProductId.trim()}>
                  {addDigistoreMutation.isPending ? "Adding..." : "Add Link"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Any Link Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 h-11" style={{ userSelect: "none" }}><Plus className="w-4 h-4" /> Add Any Link</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display">Add Affiliate Link</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Works with Warrior Plus, eBay, or any affiliate network — just paste the URL.</p>
              <div className="space-y-2">
                <Label>Product / Link Name <span className="text-muted-foreground">(required)</span></Label>
                <Input
                  placeholder="e.g. eBay Product"
                  value={jvProductName}
                  onChange={e => setJvProductName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Affiliate URL <span className="text-muted-foreground">(required)</span></Label>
                <Input
                  placeholder="https://..."
                  value={jvProductUrl}
                  onChange={e => setJvProductUrl(e.target.value)}
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" onClick={() => { setDialogOpen(false); setJvProductName(""); setJvProductUrl(""); }}>Cancel</Button>
                <Button
                  onClick={() => addAnyLinkMutation.mutate()}
                  disabled={addAnyLinkMutation.isPending || !jvProductUrl.trim() || !jvProductName.trim()}
                >
                  {addAnyLinkMutation.isPending ? "Adding..." : "Add Link"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search links..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="p-12 text-center">
          <Link2 className="w-12 h-12 mx-auto text-muted-foreground/40" />
          <p className="text-muted-foreground mt-4">No links yet — create one from a product above</p>
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Short Code</TableHead>
                  <TableHead>Clicks</TableHead>
                  <TableHead>Earnings</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((link) => (
                  <TableRow key={link.id}>
                    <TableCell className="font-medium text-sm">{link.product_name || "—"}</TableCell>
                    <TableCell>
                      <code className="text-xs bg-muted px-2 py-1 rounded font-mono">{link.short_code}</code>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <MousePointerClick className="w-3 h-3 text-muted-foreground" />
                        <Badge variant="secondary">{link.clicks || 0}</Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-emerald-500 font-medium text-sm">${(link.earnings || 0).toFixed(2)}</span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {link.created_date ? format(new Date(link.created_date), "MMM d, yyyy") : "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => copyLink(link)} aria-label={`Copy tracking link for ${link.product_name || "product"}`}>
                          <Copy className="w-3.5 h-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                          <a href={buildTrackingUrl(link)} target="_blank" rel="noopener noreferrer" aria-label={`Open tracking link for ${link.product_name || "product"}`}>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteMutation.mutate(link.id)} aria-label={`Delete ${link.product_name || "link"}`}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}
    </div>
  );
}